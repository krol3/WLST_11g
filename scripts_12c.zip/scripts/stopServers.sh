#Shell to stop domain servers
source $DM_HOME/bin/setDomainEnv.sh
java weblogic.WLST -skipWLSModuleScanning $SCRIPT_HOME/stopMS.py
exit

