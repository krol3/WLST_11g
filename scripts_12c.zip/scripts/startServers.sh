#Shell to start Admin Server First.
export JAVA_OPTIONS="-Dweblogic.security.SSL.nojce=true -Dweblogic.security.SSL.ignoreHostnameVerification=true -Djava.security.egd=file:/dev/./urandom -Dweblogic.security.SSL.enableJSSE=true"

#export PRE_CLASSPATH="/opt/oracle/mw_home/wlserver_10.3/server/lib/jsafeFIPS.jar"

source /home/oracle-fmw/user_projects/domains/osb_domain/bin/setDomainEnv.sh

echo "Starting nodemanager and weblogic servers"
java weblogic.WLST -skipWLSModuleScanning $SCRIPT_HOME/startMS.py
exit 0

