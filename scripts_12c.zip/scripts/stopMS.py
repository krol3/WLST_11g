connect('weblogic', 'welcome1', url='t3://localhost:7001')
nmConnect('weblogic', 'welcome1', domainName='osb_domain')
print " shutting down managed servers"

shutdown('osb_server1',force='true')
print " OSB Server shutdown"

print "Shutting down Admin Server"
shutdown('AdminServer',force='true')

print "Stopping node manager"
stopNodeManager()
print "Domain is down"
exit()

