import time
sleep=time.sleep

startNodeManager(verbose='true', NodeManagerHome='/home/oracle-fmw/user_projects/domains/osb_domain/nodemanager')
print 'nodemanager started'

while True:
    try:
        sleep(10)
        nmConnect('weblogic', 'welcome1', domainName='osb_domain')
        break
    except:
        sleep(30)

print 'connected to nodemanager. Starting AdminServer...'
nmStart('AdminServer')

print 'AdminServer started. Starting OSB...'
nmStart('osb_server1')

print 'osb_domain up and running'
exit()

