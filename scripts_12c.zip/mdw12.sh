#! /bin/bash
# chkconfig: 345 90 90
# description: script de start|stop do middleware Oracle 11g presente nesta maquina
​
# Source function library.
. /etc/init.d/functions
​
DM_HOME="/home/oracle-fmw/user_projects/domains/osb_domain"
SCRIPT_HOME="/home/oracle-fmw/scripts"
​
JAVA_OPTIONS="-Dweblogic.security.SSL.ignoreHostnameVerification=true -Dweblogic.ssl.JSSEEnabled=true -Dweblogic.security.SSL.enableJSSE=true -Djava.security.egd=file:/dev/./urandom -Duser.timezone=GMT"
​
fileDate=`date '+%F_%H%M'`
RETVAL=0
start() {
echo $(date) > /home/oracle-fmw/lastStart.log
touch /var/lock/subsys/middleware
export DM_HOME SCRIPT_HOME JAVA_OPTIONS
logFileName=nodemanager.log.$fileDate
chown oracle-fmw:oinstall $DM_HOME/*
su oracle-fmw -c '$SCRIPT_HOME/startServers.sh'
return $RETVAL
}
​
stop() {
echo $(date) > /home/oracle-fmw/lastStop.log
rm -f /var/lock/subsys/middleware
export DM_HOME SCRIPT_HOME JAVA_OPTIONS
chown oracle-fmw:oinstall $DM_HOME/*
su oracle-fmw -c '$SCRIPT_HOME/stopServers.sh'
return $RETVAL
}
case "$1" in
start)
start
;;
stop)
stop
;;
*)
echo $"Usage: $0 {start|stop}"
exit 1
esac
​
exit $?
